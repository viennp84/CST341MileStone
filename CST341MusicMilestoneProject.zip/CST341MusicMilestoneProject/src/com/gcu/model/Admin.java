package com.gcu.model;

public class Admin extends User {
	
	public Admin() {
		// TODO Auto-generated constructor stub
		super();
	}

}
