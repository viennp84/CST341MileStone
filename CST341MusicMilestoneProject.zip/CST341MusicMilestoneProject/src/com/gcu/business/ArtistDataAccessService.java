package com.gcu.business;

import java.util.List;

import com.gcu.dao.ArtistDataAccessObject;
import com.gcu.model.Artist;

/*
 * Vien Nguyen
 * CST341
 * 10/24/2020
 * Artist Data Access Service
 * ArtistDataAccessService will implement findAll(), create(), update(), delete() methods in the interface
 */

public class ArtistDataAccessService implements DataAccessInterface<Artist> {
	
	/*Artist data access object*/
	ArtistDataAccessObject artistDataAccessObject;
	
	

	public void setArtistDataAccessObject(ArtistDataAccessObject artistDataAccessObject) {
		this.artistDataAccessObject = artistDataAccessObject;
	}

	@Override
	public List<Artist> findAll() {
		// TODO Auto-generated method stub
		return artistDataAccessObject.findAll();
	}

	@Override
	public boolean create(Artist t) {
		// TODO Auto-generated method stub
		return artistDataAccessObject.create(t);
	}

	@Override
	public boolean update(Artist t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Artist t) {
		// TODO Auto-generated method stub
		return false;
	}

}
